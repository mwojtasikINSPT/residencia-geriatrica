package residenciageriatrica.services;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import residenciageriatrica.daos.PersonaDAO;
import residenciageriatrica.dtos.PersonaDTO;
import residenciageriatrica.utils.GeneradorCodigo;
import residenciageriatrica.utils.Validaciones;
import residenciageriatrica.daos.ReservaDAO;
import residenciageriatrica.daos.AsignacionDAO;
import residenciageriatrica.exceptions.EntidadNoEncontradaException;
import residenciageriatrica.exceptions.OperacionNoPermitidaException;

public class PersonaService {

    private final PersonaDAO personaDAO;
    private final String prefijo;

    public PersonaService(String ruta) {
        this.personaDAO = new PersonaDAO(ruta);

        String archivo = ruta.replace("\\", "/");
        archivo = archivo.substring(archivo.lastIndexOf("/") + 1);

        if (archivo.equalsIgnoreCase("residentes.txt")) {
            this.prefijo = "RES";
        } else if (archivo.equalsIgnoreCase("enfermeros.txt")) {
            this.prefijo = "ENF";
        } else {
            throw new IllegalArgumentException(
                    "Archivo de personas no válido"
            );
        }
    }

    public List<PersonaDTO> listarPersonas() {
        return personaDAO.leerTodos().stream()
                .filter(PersonaDTO::isActivo)
                .collect(Collectors.toList());
    }

    public void agregarPersona(String dni, String nombre, String apellido)
            throws IOException {

        dni = Validaciones.validarDni(dni);
        nombre = Validaciones.validarTextoObligatorio(nombre, "nombre");
        apellido = Validaciones.validarTextoObligatorio(apellido, "apellido");

        List<String> ids = personaDAO.leerTodos().stream()
                .map(PersonaDTO::getId)
                .collect(Collectors.toList());

        String id = GeneradorCodigo.generarSiguienteId(ids, prefijo);

        PersonaDTO nueva = new PersonaDTO(
                id,
                dni,
                nombre,
                apellido,
                true
        );

        personaDAO.agregar(nueva);
    }

    public PersonaDTO buscarPorId(String id) {
        return personaDAO.buscarPorId(
                Validaciones.validarCodigo(id, prefijo)
        );
    }

    public PersonaDTO buscarPorDni(String dni) {
        return personaDAO.buscarPorDni(
                Validaciones.validarDni(dni)
        );
    }

    public void eliminarPersona(String id) throws IOException {
        id = Validaciones.validarCodigo(id, prefijo);

        if (personaDAO.buscarPorId(id) == null) {
            throw new EntidadNoEncontradaException(
                    "La persona no existe o está inactiva"
            );
        }

        if (prefijo.equals("RES")) {
            ReservaDAO reservaDAO = new ReservaDAO();

            if (reservaDAO.buscarPorResidente(id) != null) {
                throw new OperacionNoPermitidaException(
                        "No se puede eliminar el residente porque tiene una reserva activa"
                );
            }
        }

        if (prefijo.equals("ENF")) {
            AsignacionDAO asignacionDAO = new AsignacionDAO();

            if (!asignacionDAO.buscarPorEnfermero(id).isEmpty()) {
                throw new OperacionNoPermitidaException(
                        "No se puede eliminar el enfermero porque tiene asignaciones activas"
                );
            }
        }

        personaDAO.eliminar(id);
    }

    public void actualizarPersona(PersonaDTO actualizada) throws IOException {
        String id = Validaciones.validarCodigo(
                actualizada.getId(), prefijo
        );

        String dni = Validaciones.validarDni(actualizada.getDni());

        String nombre = Validaciones.validarTextoObligatorio(
                actualizada.getNombre(), "nombre"
        );

        String apellido = Validaciones.validarTextoObligatorio(
                actualizada.getApellido(), "apellido"
        );

        PersonaDTO validada = new PersonaDTO(
                id,
                dni,
                nombre,
                apellido,
                true
        );

        personaDAO.actualizar(validada);
    }
}
