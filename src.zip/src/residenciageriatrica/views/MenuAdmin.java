
package residenciageriatrica.views;


public class MenuAdmin {
    
}
